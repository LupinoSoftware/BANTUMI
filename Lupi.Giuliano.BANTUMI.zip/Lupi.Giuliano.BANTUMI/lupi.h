//AUTHOR:Giuliano Lupi
//DATE:01/02/2022
//TITLE:LUPI.H
/*LIBRARY: Libreria contenente funzioni molto utili da aggiornare qualsivoglia lo si ritiene necessario.*/


/****        ****    ****   ************	****			****	****
 ****		 ****    ****   ************	****			****	****
 ****		 ****    ****   ****    **** 	****			****	****
 ****		 ****	 ****	************	****			************
 ****		 ****	 ****	************	****			************
 ****		 ****    ****   ****			****			****	****
 ****        ****	 ****	****			****			****	****
 *********    ****  ****    ****			****	****	****	****
 *********     ********     ****            ****    ****    ****    ****                                      
                        ,     ,                                    
						|\---/|                     
                       /  , , |
                  __.-'|  / \ /
         __ ___.-'        ._O|
      .-'  '        :      _/
     / ,    .        .     |
    :  ;    :        :   _/
    |  |   .'     __:   /
    |  :   /'----'| \  |
    \  |\  |      | /| |
     '.'| /       || \ |
     | /|.'       '.l \\_
     || ||             '-'
     '-''-'                                                                                                                                                                                                             */
#include <math.h>
#include <iostream>
#include <string>
#include <stdlib.h>
#include <time.h>
#include <cstdlib>
#include <sstream>
#include <bits/stdc++.h>
#include <winbgim.h>
#include <fstream>
#include <string>

using namespace std;

/*
1.Calcolare il massimo tra gli elementi interi di un array
	INPUT -> (int[])array, (int)lunghezza 
	OUTPUT -> (int) valore massimo
	
2. Calcolare il minimo degli elementi di un array
	 INPUT -> (int[])array, (int)lunghezza 
	 OUTPUT -> (int) valore minimo
	
3. Calcolare la somma degli elementi di un array
	 INPUT -> (int[])array, (int)lunghezza 
	 OUTPUT -> (float) somma

4. Calcolare la media degli elementi di un array
	 INPUT -> (int[])array, (int)lunghezza 
	 OUTPUT -> (float) media
	
5. Calcolare il valore con maggior occorrenza tra gli elementi di un array
	 INPUT -> (int[])array, (int)lunghezza 
	 OUTPUT -> (int) valore
	
6. Visualizzare un testo con contorno di *
	INPUT -> (char[])array, (int)lunghezza 
	OUTPUT -> 
	
7. Visualizzare un intero con i punti delle migliaia  
	INPUT (long long) n
	OUTPUT -> (string) n   
	   
8. Calcolare le occorrenze di ogni elemento di un array di interi 
	INPUT -> (int[])array, (int)lunghezza 
	OUTPUT -> (int) valori
       
9. Visualizzare un float con un determinato numero di decimali
	INPUT -> (double)n;
	OUTPUT -> (double) arrotondato;

10. Calcolare il valore massimo di occorrenze tra gli elementi interi di un array
	INPUT -> (int[])array, (int)lunghezza
	OUTPUT -> (int)
	
11. Caricare un array con valori interi casuali compresi tra un MIN e un MAX
	INPUT -> (int[])array, (int) lunghezza, (int) minimo, (int) massimo;
	OUTPUT -> (int[])array;

12. Restituire la posizione dello 0 tra gli elementi di un array
	INPUT -> (int[])array, int lunghezza;
	OUTPUT -> (int)pos;

13. Cercare un valore tra gli elementi di un array
	INPUT -> (int[])array, (int) lunghezza, (int) n;
	OUTPUT -> (int)pos;

14. Restituire la posizione di un valore cercato all'interno dell'array (-1 se non trovato)
	INPUT -> (int[])array, (int) lunghezza, (int) n;
	OUTPUT -> (int)pos;

15. Confronta 2 array di uguale lunghezza e restituisce -1 se il primo � minore, 0 se uguali, 1 se maggiore
	INPUT -> (int[])array1, (int[])array2, (int)lunhgezza;
	OUTPUT -> (int)finale;
	
16. Confronta 2 array (fino allo 0) e restituisce -1 se il primo � minore, 0 se uguali, 1 se maggiore
	INPUT -> (int[])array1, (int[])array2, (int)lunhgezza;
	OUTPUT -> (int)finale;
	
17. Restituisce il codice ASCII di un carattere
	INPUT -> (char)carattere;
	OUTPUT -> (int)numero;

18. Restituisce il carattere dato un codice ASCII
	INPUT -> (int) numero;
	OUTPUT -> (char)carattere;

19. Stampare a video n caratteri corrispondenti ai codici ASCII per ogni elemento del vettore fino allo 0
	INPUT -> (int[])array, (int)lunghezza;
	OUTPUT -> (char)caratteri;

20. Calcolare se il valore intero � primo
	INPUT -> (int)n;
	OUTPUT -> (bool) primo

21. Rende FullScreen il terminale

22. Apre un'immagine .bmp tramite la lettura dei singoli bit
	INTPUT -> (char)nomefile;
	OUTPUT -> Immagine

23. BANTUMI Genera un semplice men� formato da n opzioni
	INPUT -> (int) Colore del contorno, (Int) Colore del testo
	OUTPUT -> Men�

24. BANTUMI Funzione per la creazione di un nome tramite la scelta delle lettere di un array char
	INPUT -> (Int)Numero della lettera, (Int)Ascissa della lettera, (Int)Ordinata della lettera, (Int)Grandezza dei caratteri, (Int)Contatore per l'array dichar, (Char[])Array del nome
	OUTPUT -> (Char)Array

25. BANTUMI Genera i numeri che cambiano sul tabellone tramite outtext(x,y,stringa)
	INPUT -> (Int)Numero, (Int)Posizione di un eventuale array
	OUTPUT -> (String)Numero

*/

/* ____----****PROTOTIPI****----____ */
//FUNZIONE 1
int massimo(int array[], int lunghezza); //prototipo della funzione

//FUNZIONE 2
int minimo(int array[], int lunghezza);

//FUNZIONE 3
long long somma(long long array[], long long lunghezza);

//FUNZIONE 4
float media(float array[], float lunghezza);

//FUNZIONE 5
int occorrenza(int array[], int lunghezza);

//FUNZIONE 6
void contorno (string s);

//FUNZIONE 7
string migliaia (long long n);

//FUNZIONE 8
void frequenza(int array[], int lunghezza);

//FUNZIONE 9
double decimali (double n, int cifre);

//FUNZIONE 10
void occorrenzaMax(int array [], int lunghezza);

//FUNZIONE 11
void carica(int array[], int lunghezza, int minimo, int massimo);

//FUNZIONE 12
int posizioneZero(int array[], int lunghezza);

//FUNZIONE 13
int posizione(int array[], int lunghezza, int n);

//FUNZIONE 14
int posizioneReturn(int array[], int lunghezza, int n);

//FUNZIONE 15
int confrontoLunghezza(int array1[], int array2[], int lunghezza);

//FUNZIONE 16
int confrontoLunghezzaZero(int array1[], int array2[], int lunghezza);

//FUNZIONE 17
int charInt(char carattere); 

//FUNZIONE 18
char intChar(int numero);

//FUNZIONE 19
char arrayIntChar(int array[], int lunghezza);

//FUZIONE 20
void primo(int n);

//FUNZIONE 21

//FUNZIONE 22
void leggiBMP(char* filename);

//FUNZIONE 23
void menuHD(int box_color,int text_color);

//Funzione 24
void alfabetoNome (int lettera, int xlettera, int ylettera, int glettera, int i, char nome[]);

//Funzione 25
void outNumeri(int n, int ciotola);

/* ____----****IMPLEMENTAZIONE****----____ */
//FUNZIONE 1
int massimo(int array[], int lunghezza){
	if (lunghezza<=0) return pow(2.0,-16);
	int max=array[0];
	for (int i=1; i<lunghezza; i++){
		if (array[i]>max){array[i]=max;}
	}
	return max;
}

//FUNZIONE 2
int minimo(int array[], int lunghezza){
	if (lunghezza<=0) return pow(2.0,16);
	int min=array[0];
	for (int i=1; i<lunghezza; i++){
		if (array[i]<min){array[i]=min;}
	}
	return min;
}

//FUNZIONE 3
long long somma(long long array[], long long lunghezza){
	long long somma=0;
	for(long long i=0; i<lunghezza; i++){somma=somma+array[i];}
	return somma;
}

//FUNZIONE 4
float media(float array[], float lunghezza){	
	(float)lunghezza;
	float risultato;
	float somma=0;
	for(int i=0; i<lunghezza; i++){
		somma=somma+array[i];
	}
	risultato=somma/lunghezza;
	return risultato;
}

//FUNZIONE 5
int occorrenza(int array[], int lunghezza){
	int occorrenza=0;
	int occorrenzamax=0;
	int valore;
	for (int i=0; i<lunghezza; i++){
		for(int k=0; k<lunghezza; k++){
			if(array[k]==array[i]){	occorrenza+=1;}
		}
		if (occorrenzamax<occorrenza){occorrenzamax=occorrenza; valore=array[i];}
		occorrenza=0;
	}
	return valore;
}

//FUNZIONE 6
void contorno (string s){
	for(int i = 0; i < s.size() + 4; i++){cout<<"*";}
	cout<<endl;
	for(int i = 0; i < s.size() + 4; i++){if(i==0 || i==s.size()+3){cout<<"*";} else{cout<<" ";}}
    cout<<"\n* "<<s<<" *\n";
    for(int i = 0; i < s.size() + 4; i++){if(i==0 || i==s.size()+3){cout<<"*";} else{cout<<" ";}}
    cout<<endl;
    for(int i = 0; i < s.size() + 4; i++){cout<<"*";}
}

//FUNZIONE 7
string migliaia (long long n){
	string ans = "";
  	stringstream ss;
	ss<<n;
	string num;
	ss>>num;
    int cont = 0;
    for (int i = num.size() - 1;i >= 0; i--) {
        cont++;
        ans.push_back(num[i]);
        if (cont == 3) {
            ans.push_back('.');
            cont = 0;
        }
    }
    reverse(ans.begin(), ans.end());
    if (ans.size() % 4 == 0) {
        ans.erase(ans.begin());
    }
    return ans;
}

//FUNZIONE 8
void frequenza(int array[], int lunghezza){
	int frequenza=0;
	for (int i=0; i<lunghezza; i++){
		for(int k=0; k<lunghezza; k++){
			if(array[i]==array[k]){	frequenza+=1;}
		}
		cout<<"\nIl "<<array[i]<<" \x8a ripetuto "<<frequenza<<" volte"<<endl;
		frequenza=0;
	}
}

//FUNZIONE 9
double decimali (double n, int cifre){
	n=n*pow(10,cifre);
	long long num=(long long) n;
	double arrotondato=num/pow(10,cifre);
	return arrotondato;
}

//FUNZIONE 10
void occorrenzaMax(int array[], int lunghezza){
	int occorrenza=0;
	int nmax;
	for (int i=0; i<lunghezza; i++){
		int cont=0;
		for(int k=0; k<lunghezza; k++){
			if(array[i]==array[k]){cont=cont+1;}
		}
		if(cont>occorrenza){occorrenza=cont; nmax=array[i];}
	}
	cout<<"Il valore ripetuto piu' volte \x8a "<<nmax<<endl;
}

//FUNZIONE 11
void carica(int array[], int lunghezza, int minimo, int massimo){
	srand(time(NULL));
	for(int i=0; i<lunghezza; i++){
		int n=rand()%massimo+minimo;
		array[i]=n;
		cout<<array[i]<<" ";
	}
}

//FUNZIONE 12
int posizioneZero(int array[], int lunghezza){
	bool trovato=false;
	int pos;
	for (int i=0; i<lunghezza; i++){
		if (array[i]==0){trovato=true; pos=i+1; break;}
	}
	if(trovato==false){
		pos=-1;
	}
	return pos;
}

//FUNZIONE 13
int posizione(int array[], int lunghezza, int n){
	bool trovato=false;
	int pos=0;
	for (int i=0; i<lunghezza; i++){
		if (array[i]==n){trovato=true; pos=i+1; break;}
	}
	return pos;
}

//FUNZIONE 14
int posizioneReturn(int array[], int lunghezza, int n){
	bool trovato=false;
	int pos;
	for (int i=0; i<lunghezza; i++){
		if (array[i]==n){trovato=true; pos=i+1;}
	}
	if(trovato==false){
		pos=-1;
	}
	return pos;
}

//FUNZIONE 15
int confrontoLunghezza(int array1[], int array2[], int lunghezza){
	int finale;
	for (int i=0; i<lunghezza; i++){
		if(array1[i]<array2[i]){ finale=-1;}
		if(array1[i]==array2[i]){finale=0;}
		if(array1[i]>array2[i]){finale=1;}
	}
	return finale;
}

//FUNZIONE 16
int confrontoLunghezzaZero(int array1[], int array2[], int lunghezza){
	int finale;
	for (int i=0; i<lunghezza; i++){
		if(array1[i]<array2[i]){ finale=-1;}
		if(array1[i]==array2[i]){finale=0;}
		if(array1[i]>array2[i]){finale=1;}
		if(array1[i]==0 || array2[i]==0){break;}
	}
	return finale;
}

//FUNZIONE 17
int charInt(char carattere){
	int numero= (int)carattere;
	return numero;
}

//FUNZIONE 18
char intChar(int numero){
	char carattere= (char)numero;
	return carattere;
}

//FUNZIONE 19
char arrayIntChar(int array[], int lunghezza){
	for(int i=0; i<lunghezza; i++){
		char carattere= (char)array[i];
		return carattere;
	}
}

//FUZIONE 20
void primo(int n){
	bool primo;
	for (int i=2; i<=n/2; i++){
		if(n%i==0){primo=false; break;}
		else{primo=true;}
	}
	if (primo==true){cout<<"Il numero \x8a primo.\n";}
	else{cout<<"Il numero non \x8a primo.\n";}
}

//FUNZIONE 21

//FUNZIONE 22
void leggiBMP(char* filename){
    int i;
    FILE* f = fopen(filename, "rb");
    unsigned char info[54];

    // read the 54-byte header
    fread(info, sizeof(unsigned char), 54, f);

    // extract image height and width from header
    int width = *(int*)&info[18];
    int height = *(int*)&info[22];
   //     std::cout<<width<<" x "<<height<<std::endl;
    // allocate 3 bytes per pixel
    int size = 3 * width * height;
    int off=0;
        int of=0;
        if ((width*3+of)%4!=0) of=2;
        size+=of*height;
   
    unsigned char* data = new unsigned char[size];
       

    // read the rest of the data at once
    fread(data, sizeof(unsigned char), size, f);  //devo leggere anche gli spazi tra una riga %8 e l'altra
    fclose(f);
   
       
      //  std::cout<<of<<" offset "<<std::endl;
        for(int y = 0; y < height; y ++){
             for(int x = 0; x < width; x ++){
                        putpixel(x,height-y,COLOR((int)data[y*width*3+x*3+off+2],(int)data[y*width*3+x*3+1+off],(int)data[y*width*3+x*3+off]));
                 }
                off+=of;
        }
}

//ZONA BANTUMI
// FUNZIONE 23
void menuHD(int box_color,int text_color){
	int menux=800;
	int menuy=350;
	setcolor(box_color);
    //for(int i=0;i<100;i++)
	//rectangle(110-i,150-i,580+i,430+i);
	settextstyle(GOTHIC_FONT,HORIZ_DIR,10);
	outtextxy(560,90,"BANTUMI");
	settextstyle(GOTHIC_FONT,HORIZ_DIR,4);
	outtextxy(880,220,"t h e  g a m e");
	setfillstyle(5,COLOR(255,0,0));
    setcolor(text_color);
	settextstyle(GOTHIC_FONT,HORIZ_DIR,8);
	outtextxy(menux+30,menuy,"GIOCA");
	outtextxy(menux-20,menuy+160,"OPZIONI");
	outtextxy(menux+60,menuy+320,"ESCI");		
}
void opzioniHD(int semiIniziali){
}

//FUNZIONE 24
void alfabetoNome (int lettera, int xlettera, int ylettera, int glettera, int i, char nome[]){
			int ColoreRet1=COLOR(0,0,3);
			int ColoreRet2=COLOR(0,0,3);
			switch (lettera){
				case 1:{
					delay(1);
					//cout<<"Sto qui";
					//settextstyle(10,5,9);
					setcolor(ColoreRet1);
					rectangle(xlettera-20,ylettera-10,xlettera+90,ylettera+90);
					setfillstyle(1,ColoreRet2);
					floodfill(xlettera,ylettera,ColoreRet1);
					setcolor(COLOR(255,255,255));
					settextstyle(0,HORIZ_DIR,glettera);
					outtextxy(xlettera,ylettera,"A");
					//char c='A';
					//int n = (int) c;
					//nome[i]={n};
					nome[i]={'A'};
					break;
				}
				case 2:{
					delay(1);
					//cout<<"Mo sto alla B;
					//settextstyle(10,5,9);
					//setcolor(nero);
					//rectangle(xlettera-540,ylettera,xlettera-500,ylettera+50);
					//setfillstyle(1,arancio);
					//floodfill(x1lettera-530,y1lettera+30,nero);
					//setcolor(stelle);
					setcolor(ColoreRet1);
					rectangle(xlettera-20,ylettera-10,xlettera+90,ylettera+90);
					setfillstyle(1,ColoreRet2);
					floodfill(xlettera,ylettera,ColoreRet1);
					setcolor(COLOR(255,255,255));
					settextstyle(0,HORIZ_DIR,glettera);
					outtextxy(xlettera,ylettera,"B");
					//char c='B';
					//int n = (int) c;
					//nome[i]={n};
					nome[i]='B';
					break;
				}
				case 3:{
					delay(1);
					//cout<<"Siamo alla C";
					setcolor(ColoreRet1);
					rectangle(xlettera-20,ylettera-10,xlettera+90,ylettera+90);
					setfillstyle(1,ColoreRet2);
					floodfill(xlettera,ylettera,ColoreRet1);
					setcolor(COLOR(255,255,255));
					settextstyle(0,HORIZ_DIR,glettera);
					outtextxy(xlettera,ylettera,"C");
					//char c='C';
    				///int n = (int) c;
					//nome[i]={n};
					nome[i]='C';
					break;
				}
				case 4:{
					delay(1);
					//cout<<"E oraalla D";
					setcolor(ColoreRet1);
					rectangle(xlettera-20,ylettera-10,xlettera+90,ylettera+90);
					setfillstyle(1,ColoreRet2);
					floodfill(xlettera,ylettera,ColoreRet1);
					setcolor(COLOR(255,255,255));
					settextstyle(0,HORIZ_DIR,glettera);
					outtextxy(xlettera,ylettera,"D");
					//char c='D';
					//int n = (int) c;
					//nome[i]={n};
					nome[i]='D';
					break;
				}
				case 5:{
					delay(1);
					setcolor(ColoreRet1);
					rectangle(xlettera-20,ylettera-10,xlettera+90,ylettera+90);
					setfillstyle(1,ColoreRet2);
					floodfill(xlettera,ylettera,ColoreRet1);
					setcolor(COLOR(255,255,255));
					settextstyle(0,HORIZ_DIR,glettera);
					outtextxy(xlettera,ylettera,"E");
					nome[i]='E';
					break;
				}
				case 6:{
					delay(1);
					setcolor(ColoreRet1);
					rectangle(xlettera-20,ylettera-10,xlettera+90,ylettera+90);
					setfillstyle(1,ColoreRet2);
					floodfill(xlettera,ylettera,ColoreRet1);
					setcolor(COLOR(255,255,255));
					settextstyle(0,HORIZ_DIR,glettera);
					outtextxy(xlettera,ylettera,"F");
					nome[i]='F';
					break;
				}
				case 7:{
					delay(1);
					setcolor(ColoreRet1);
					rectangle(xlettera-20,ylettera-10,xlettera+90,ylettera+90);
					setfillstyle(1,ColoreRet2);
					floodfill(xlettera,ylettera,ColoreRet1);
					setcolor(COLOR(255,255,255));
					settextstyle(0,HORIZ_DIR,glettera);
					outtextxy(xlettera,ylettera,"G");
					nome[i]='G';
					break;
				}
				case 8:{
					delay(1);
					setcolor(ColoreRet1);
					rectangle(xlettera-20,ylettera-10,xlettera+90,ylettera+90);
					setfillstyle(1,ColoreRet2);
					floodfill(xlettera,ylettera,ColoreRet1);
					setcolor(COLOR(255,255,255));
					settextstyle(0,HORIZ_DIR,glettera);
					outtextxy(xlettera,ylettera,"H");
					nome[i]='H';
					break;
				}
				case 9:{
					delay(1);
					setcolor(ColoreRet1);
					rectangle(xlettera-20,ylettera-10,xlettera+90,ylettera+90);
					setfillstyle(1,ColoreRet2);
					floodfill(xlettera,ylettera,ColoreRet1);
					setcolor(COLOR(255,255,255));
					settextstyle(0,HORIZ_DIR,glettera);
					outtextxy(xlettera,ylettera,"I");
					nome[i]='I';
					break;
				}	
				case 10:{
					delay(1);
					setcolor(ColoreRet1);
					rectangle(xlettera-20,ylettera-10,xlettera+90,ylettera+90);
					setfillstyle(1,ColoreRet2);
					floodfill(xlettera,ylettera,ColoreRet1);
					setcolor(COLOR(255,255,255));
					settextstyle(0,HORIZ_DIR,glettera);
					outtextxy(xlettera,ylettera,"J");
					nome[i]='J';
					break;
				}
				case 11:{
					delay(1);
					setcolor(ColoreRet1);
					rectangle(xlettera-20,ylettera-10,xlettera+90,ylettera+90);
					setfillstyle(1,ColoreRet2);
					floodfill(xlettera,ylettera,ColoreRet1);
					setcolor(COLOR(255,255,255));
					settextstyle(0,HORIZ_DIR,glettera);
					outtextxy(xlettera,ylettera,"K");
					nome[i]='K';
					break;
				}
				case 12:{
					delay(1);
					setcolor(ColoreRet1);
					rectangle(xlettera-20,ylettera-10,xlettera+90,ylettera+90);
					setfillstyle(1,ColoreRet2);
					floodfill(xlettera,ylettera,ColoreRet1);
					setcolor(COLOR(255,255,255));
					settextstyle(0,HORIZ_DIR,glettera);
					outtextxy(xlettera,ylettera,"L");
					nome[i]='L';
					break;
				}
				case 13:{
					delay(1);
					setcolor(ColoreRet1);
					rectangle(xlettera-20,ylettera-10,xlettera+90,ylettera+90);
					setfillstyle(1,ColoreRet2);
					floodfill(xlettera,ylettera,ColoreRet2);
					setcolor(COLOR(255,255,255));
					settextstyle(0,HORIZ_DIR,glettera);
					outtextxy(xlettera,ylettera,"M");
					nome[i]='M';
					break;
				}
				case 14:{
					delay(1);
					setcolor(ColoreRet1);
					rectangle(xlettera-20,ylettera-10,xlettera+90,ylettera+90);
					setfillstyle(1,ColoreRet2);
					floodfill(xlettera,ylettera,ColoreRet1);
					setcolor(COLOR(255,255,255));
					settextstyle(0,HORIZ_DIR,glettera);
					outtextxy(xlettera,ylettera,"N");
					nome[i]='N';
					break;
				}
				case 15:{
					delay(1);
					setcolor(ColoreRet1);
					rectangle(xlettera-20,ylettera-10,xlettera+90,ylettera+90);
					setfillstyle(1,ColoreRet2);
					floodfill(xlettera,ylettera,ColoreRet1);
					setcolor(COLOR(255,255,255));
					settextstyle(0,HORIZ_DIR,glettera);
					outtextxy(xlettera,ylettera,"O");
					nome[i]='O';
					break;
				}
				case 16:{
					delay(1);
					setcolor(ColoreRet1);
					rectangle(xlettera-20,ylettera-10,xlettera+90,ylettera+90);
					setfillstyle(1,ColoreRet2);
					floodfill(xlettera,ylettera,ColoreRet1);
					setcolor(COLOR(255,255,255));
					settextstyle(0,HORIZ_DIR,glettera);
					outtextxy(xlettera,ylettera,"P");
					nome[i]='P';
					break;
				}
				case 17:{
					delay(1);
					setcolor(ColoreRet1);
					rectangle(xlettera-20,ylettera-10,xlettera+90,ylettera+90);
					setfillstyle(1,ColoreRet2);
					floodfill(xlettera,ylettera,ColoreRet1);
					setcolor(COLOR(255,255,255));
					settextstyle(0,HORIZ_DIR,glettera);
					outtextxy(xlettera,ylettera,"Q");
					nome[i]='Q';
					break;
				}
				case 18:{
					delay(1);
					setcolor(ColoreRet1);
					rectangle(xlettera-20,ylettera-10,xlettera+90,ylettera+90);
					setfillstyle(1,ColoreRet2);
					floodfill(xlettera,ylettera,ColoreRet1);
					setcolor(COLOR(255,255,255));
					settextstyle(0,HORIZ_DIR,glettera);
					outtextxy(xlettera,ylettera,"R");
					nome[i]='R';
					break;
				}
				case 19:{
					delay(1);
					setcolor(ColoreRet1);
					rectangle(xlettera-20,ylettera-10,xlettera+90,ylettera+90);
					setfillstyle(1,ColoreRet2);
					floodfill(xlettera,ylettera,ColoreRet1);
					setcolor(COLOR(255,255,255));
					settextstyle(0,HORIZ_DIR,glettera);
					outtextxy(xlettera,ylettera,"S");
					nome[i]='S';
					break;
				}
				case 20:{
					delay(1);
					setcolor(ColoreRet1);
					rectangle(xlettera-20,ylettera-10,xlettera+90,ylettera+90);
					setfillstyle(1,ColoreRet2);
					floodfill(xlettera,ylettera,ColoreRet1);
					setcolor(COLOR(255,255,255));
					settextstyle(0,HORIZ_DIR,glettera);
					outtextxy(xlettera,ylettera,"T");
					nome[i]='T';
					break;
				}
				case 21:{
					delay(1);
					setcolor(ColoreRet1);
					rectangle(xlettera-20,ylettera-10,xlettera+90,ylettera+90);
					setfillstyle(1,ColoreRet2);
					floodfill(xlettera,ylettera,ColoreRet1);
					setcolor(COLOR(255,255,255));
					settextstyle(0,HORIZ_DIR,glettera);
					outtextxy(xlettera,ylettera,"U");
					nome[i]='U';
					break;
				}
				case 22:{
					delay(1);
					setcolor(ColoreRet1);
					rectangle(xlettera-20,ylettera-10,xlettera+90,ylettera+90);
					setfillstyle(1,ColoreRet2);
					floodfill(xlettera,ylettera,ColoreRet1);
					setcolor(COLOR(255,255,255));
					settextstyle(0,HORIZ_DIR,glettera);
					outtextxy(xlettera,ylettera,"V");
					nome[i]='V';
					break;
				}
				case 23:{
					delay(1);
					setcolor(ColoreRet1);
					rectangle(xlettera-20,ylettera-10,xlettera+90,ylettera+90);
					setfillstyle(1,ColoreRet2);
					floodfill(xlettera,ylettera,ColoreRet1);
					setcolor(COLOR(255,255,255));
					settextstyle(0,HORIZ_DIR,glettera);
					outtextxy(xlettera,ylettera,"W");
					nome[i]='W';
					break;
				}
				case 24:{
					delay(1);
					setcolor(ColoreRet1);
					rectangle(xlettera-20,ylettera-10,xlettera+90,ylettera+90);
					setfillstyle(1,ColoreRet2);
					floodfill(xlettera,ylettera,ColoreRet1);
					setcolor(COLOR(255,255,255));
					settextstyle(0,HORIZ_DIR,glettera);
					outtextxy(xlettera,ylettera,"X");
					nome[i]='X';
					break;
				}
				case 25:{
					delay(1);
					setcolor(ColoreRet1);
					rectangle(xlettera-20,ylettera-10,xlettera+90,ylettera+90);
					setfillstyle(1,ColoreRet2);
					floodfill(xlettera,ylettera,ColoreRet1);
					setcolor(COLOR(255,255,255));
					settextstyle(0,HORIZ_DIR,glettera);
					outtextxy(xlettera,ylettera,"Y");
					nome[i]='Y';
					break;
				}
				case 26:{
					delay(1);
					setcolor(ColoreRet1);
					rectangle(xlettera-20,ylettera-10,xlettera+90,ylettera+90);
					setfillstyle(1,ColoreRet2);
					floodfill(xlettera,ylettera,ColoreRet1);
					setcolor(COLOR(255,255,255));
					settextstyle(0,HORIZ_DIR,glettera);
					outtextxy(xlettera,ylettera,"Z");
					nome[i]='Z';
					break;
				}
			}
}

//FUNZIONE 25
void outNumeri(int n, int ciotola){
	int temp=n;
	int xIniziali=390;//Posizione x di partenza
	int yIniziali=690;//Posizione y di partenza
	int gLettere=6;//Grandezza dei numeri
	int fLettere=3;//Font dei numeri
    char numero[3]={' ',' ','\0'};
    if (n>=10)
    {
        int decine=n/10;
        n=n-decine*10;
        numero[0]=char(decine+48);
        numero[1]=char(n+48);
    }
    else
    {
        numero[0]=char(n+48);
    }
	switch (ciotola){
		case 0:{
			settextstyle(fLettere,HORIZ_DIR,gLettere);
			delay(1);
			setcolor(COLOR(0,0,1));
			rectangle(xIniziali-30,yIniziali-30,xIniziali+60,yIniziali+60);
			setfillstyle(1,COLOR(0,0,0));
			floodfill(xIniziali,yIniziali,COLOR(0,0,1));
			setcolor(COLOR(255,255,255));
			outtextxy(xIniziali, yIniziali, numero);
			break;
		}
		case 1:{
			settextstyle(fLettere,HORIZ_DIR,gLettere);
			delay(1);
			setcolor(COLOR(0,0,1));
			rectangle(xIniziali+190,yIniziali-30,xIniziali+280,yIniziali+60);
			setfillstyle(1,COLOR(0,0,0));
			floodfill(xIniziali+230,yIniziali,COLOR(0,0,1));
			setcolor(COLOR(255,255,255));
			outtextxy(xIniziali+220, yIniziali, numero);
			break;
		}
		case 2:{
			settextstyle(fLettere,HORIZ_DIR,gLettere);
			delay(1);
			setcolor(COLOR(0,0,1));
			rectangle(xIniziali+410,yIniziali-30,xIniziali+500,yIniziali+60);
			setfillstyle(1,COLOR(0,0,0));
			floodfill(xIniziali+450,yIniziali,COLOR(0,0,1));
			setcolor(COLOR(255,255,255));
			outtextxy(xIniziali+440, yIniziali, numero);
			break;
		}
		case 3:{
			settextstyle(fLettere,HORIZ_DIR,gLettere);
			delay(1);
			setcolor(COLOR(0,0,1));
			rectangle(xIniziali+630,yIniziali-30,xIniziali+720,yIniziali+60);
			setfillstyle(1,COLOR(0,0,0));
			floodfill(xIniziali+700,yIniziali,COLOR(0,0,1));
			setcolor(COLOR(255,255,255));
			outtextxy(xIniziali+660, yIniziali, numero);
			break;
		}
		case 4:{
			settextstyle(fLettere,HORIZ_DIR,gLettere);
			delay(1);
			setcolor(COLOR(0,0,1));
			rectangle(xIniziali+850,yIniziali-30,xIniziali+940,yIniziali+60);
			setfillstyle(1,COLOR(0,0,0));
			floodfill(xIniziali+900,yIniziali,COLOR(0,0,1));
			setcolor(COLOR(255,255,255));
			outtextxy(xIniziali+880, yIniziali, numero);
			break;
		}
		case 5:{
			settextstyle(fLettere,HORIZ_DIR,gLettere);
			delay(1);
			setcolor(COLOR(0,0,1));
			rectangle(xIniziali+1070,yIniziali-30,xIniziali+1160,yIniziali+60);
			setfillstyle(1,COLOR(0,0,0));
			floodfill(xIniziali+1100,yIniziali,COLOR(0,0,1));
			setcolor(COLOR(255,255,255));
			outtextxy(xIniziali+1100, yIniziali, numero);
			break;
		}
		case 6:{
			settextstyle(fLettere,HORIZ_DIR,gLettere);
			delay(1);
			setcolor(COLOR(0,0,1));
			rectangle(1691,505-30,1721+60,505+60);
			setfillstyle(1,COLOR(0,0,0));
			floodfill(1700,505,COLOR(0,0,1));
			setcolor(COLOR(255,255,255));
			outtextxy(1721, 505, numero);
			break;
		}
		case 7:{
			settextstyle(fLettere,HORIZ_DIR,gLettere);
			delay(1);
			setcolor(COLOR(0,0,1));
			rectangle(xIniziali+1100-30,yIniziali-377-30,xIniziali+1100+60,yIniziali-377+60);
			setfillstyle(1,COLOR(0,0,0));
			floodfill(xIniziali+1100,yIniziali-377,COLOR(0,0,1));
			setcolor(COLOR(255,255,255));
			outtextxy(xIniziali+1100, yIniziali-377, numero);
			break;
		}
		case 8:{
			settextstyle(fLettere,HORIZ_DIR,gLettere);
			delay(1);
			setcolor(COLOR(0,0,1));
			rectangle(xIniziali+880-30,yIniziali-377-30,xIniziali+880+60,yIniziali-377+60);
			setfillstyle(1,COLOR(0,0,0));
			floodfill(xIniziali+880,yIniziali-377,COLOR(0,0,1));
			setcolor(COLOR(255,255,255));
			outtextxy(xIniziali+880, yIniziali-377, numero);
			break;
		}
		case 9:{
			settextstyle(fLettere,HORIZ_DIR,gLettere);
			delay(1);
			setcolor(COLOR(0,0,1));
			rectangle(xIniziali+660-30,yIniziali-377-30,xIniziali+660+60,yIniziali-377+60);
			setfillstyle(1,COLOR(0,0,0));
			floodfill(xIniziali+660,yIniziali-377,COLOR(0,0,1));
			setcolor(COLOR(255,255,255));
			outtextxy(xIniziali+660, yIniziali-377, numero);
			break;
		}
		case 10:{
			settextstyle(fLettere,HORIZ_DIR,gLettere);
			delay(1);
			setcolor(COLOR(0,0,1));
			rectangle(xIniziali+440-30,yIniziali-377-30,xIniziali+440+60,yIniziali-377+60);
			setfillstyle(1,COLOR(0,0,0));
			floodfill(xIniziali+440,yIniziali-377,COLOR(0,0,1));
			setcolor(COLOR(255,255,255));
			outtextxy(xIniziali+440, yIniziali-377, numero);
			break;
		}
		case 11:{
			settextstyle(fLettere,HORIZ_DIR,gLettere);
			delay(1);
			setcolor(COLOR(0,0,1));
			rectangle(xIniziali-30+220,yIniziali-30-377,xIniziali+60+220,yIniziali+60-377);
			setfillstyle(1,COLOR(0,0,0));
			floodfill(xIniziali+220,yIniziali-377,COLOR(0,0,1));
			setcolor(COLOR(255,255,255));
			outtextxy(xIniziali+220, yIniziali-377, numero);
			break;
		}
		case 12:{
			settextstyle(fLettere,HORIZ_DIR,gLettere);
			delay(1);
			setcolor(COLOR(0,0,1));
			rectangle(xIniziali-30,yIniziali-377-30,xIniziali+60,yIniziali-377+60);
			setfillstyle(1,COLOR(0,0,0));
			floodfill(xIniziali,yIniziali-377,COLOR(0,0,1));
			setcolor(COLOR(255,255,255));
			outtextxy(xIniziali, yIniziali-377, numero);
			break;
		}
		case 13:{
			settextstyle(fLettere,HORIZ_DIR,gLettere);
			delay(1);
			setcolor(COLOR(0,0,1));
			rectangle(135-30,437-30,135+60,437+60);
			setfillstyle(1,COLOR(0,0,0));
			floodfill(135,437,COLOR(0,0,1));
			setcolor(COLOR(255,255,255));
			outtextxy(135, 437, numero);
			break;
		}
	}
}

void rounded(int x, int y, int b, int h, int raggio){
	line(x+raggio,y,b+x,y);
	line(x+raggio,h+y+raggio,b+x,h+y+raggio);

	line(x,y+raggio,x,h+y);
	line(b+x+raggio,y+raggio,b+x+raggio,h+y);
	
	arc(x+raggio,y+raggio,90,180,raggio);
	arc(x+b,y+raggio,0,90,raggio);
	arc(x+raggio,y+h,180,270,raggio);
	arc(x+b,y+h,270,0,raggio);
}	

void GeneraStelle(int colore,int temporaneo){
	setlinestyle(0,0,2);
	for (int i=0; i<1000;i++){
		int stellax=rand()%getmaxx();
    	int stellay=rand()%getmaxy();
		int raggio=2;
		setcolor(temporaneo);
		circle(stellax,stellay,raggio);
		setfillstyle(1,colore);
		floodfill(stellax,stellay,temporaneo);
		setcolor(colore);
		circle(stellax,stellay,raggio);
	}
}
									
