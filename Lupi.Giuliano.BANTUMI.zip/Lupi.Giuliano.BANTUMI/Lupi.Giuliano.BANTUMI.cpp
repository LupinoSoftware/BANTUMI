// AUTHOR:Giuliano Lupi
//DATE:26/02/2022
//TITLE:BANTUMI 
/*ALGORITHM:Esaustiva ricostruzione del noto gioco Bantumi o Kalah provvista di una modalit� PVP per divertirsi in compagnia e PVE per sfidare se stessi!.*/

#include <winbgim.h>
#include <string>
#include <iostream>
#include "lupi.h"
#include<conio.h>
 using namespace std;
int main()
{
   	int box_color=11;
   	int text_color=3;
   	
   	//VALORI OPZIONI
   	int semiIniziali=3;
	int tipo=0;
	int sfondo=1;
	int musica=0;
   	   	
   	//COLORI
	int brown_scuro=COLOR(181,148,131);
	int ball=COLOR(255,0,0);
	int rosso=COLOR(255,0,0);
	int arancio=COLOR(255,128,0);
	int giallo=COLOR(255,255,0);
	int verde=COLOR(0,255,0);
	int azzurro_chiaro=COLOR(0,255,255);
	int azzurro=COLOR(0,128,255);
	int blu=COLOR(0,0,255);
	int viola=COLOR(127,0,255);
	int rosa=COLOR(255,0,255);
	int brown=COLOR(189,115,52);
	int stelle=COLOR(255,255,255);
	int temporaneo=COLOR(254,0,0);
	int bianco=COLOR(255,255,254);
	int spazio=COLOR(0,0,0);
	int nero=COLOR(0,0,1);
	bool menu=true;
	bool esci=false;
	bool sigioca=false;
   	do{
		initwindow(1920,1080);
   		menu=true;
   		esci=false;
   		cout<<"Sto qui scemoito!(nel menu)\n";
	   	setcolor(text_color);
	   	menuHD(box_color,text_color);
		int x,y;
		bool mouse=false;
		bool mouseno=false;
		//CONTROLLO SALVA OPZIONI 
		cout<<semiIniziali;
		cout<<tipo;
		cout<<sfondo;
		cout<<musica;
		if(esci==true){cout<<"esci \x8a true\n";	}
		while(!ismouseclick(WM_LBUTTONDOWN) && esci==false){
			delay(1);
			x=mousex();
			y=mousey();
			//SE CLICCHI GIOCA
			if(GetAsyncKeyState(VK_LBUTTON) && x>800 && x<1200 && y>350 && y<420 && menu==true){//Se gioco, da questo if non devo uscire
				cout<<"Sono in GIOCA\n";
				esci=false;
				mouse=true;
				menu=false;
				//CONTROLLO SALVA OPZIONI 2.0
				cout<<semiIniziali;
				cout<<tipo;
				cout<<sfondo;
				cout<<musica;
				closegraph();
				initwindow(1920,1080);
				delay(1);
				char nome [8]={' ',' ',' ',' ',' ',' ',' ','\0'};//Si hai messo uno slot in pi�, Grazie giuliano del passato, Ne serviva un altro!, Eh questi dialoghi di altri tempi... 
				char nome2 [8]={' ',' ',' ',' ',' ',' ',' ','\0'};
				char nomeCPU [8]={'R','O','B',' ','B','O','T','\0'};
				int lettere=7;
				int nomex=getmaxx()/2;
				int nomey=getmaxy()/3;
				int x1nome=970, y1nome=300, x2nome=1100, y2nome=420;
				int x1lettera=x1nome, y1lettera=y1nome, x2lettera=x2nome,y2lettera=y2nome;
				int xlettera=450;
				int ylettera=320;
				int glettera=10;
				int lettera1=0, lettera2=0, lettera3=0, lettera4=0, lettera5=0, lettera6=0, lettera7=0;
				int salvax1=1370, salvay1=600, salvax2=620, salvay2=650;
				int salvascrittax=940, salvascrittay=610;
				//PREGIOCO
				bool pronti=false;
				bool prontiPvp=false;
				//IMPOSTAZIONI PVE
				if(tipo==1 && pronti==false){//Se ho cliccato gioca, vado avanti e salto la selezione
					delay(1);
					cout<<"Disegno il pregioco\n";
					setfillstyle(1,spazio);
					for(int i=0; i<lettere; i++){
							setcolor(bianco);
							bar3d(x1nome-550,y1nome,x2nome-550,y2nome,10,1);
							x1nome+=170;
							x2nome+=170;
							cout<<"Ho disegnato un elemento del pregioco\n";
					}
					setcolor(stelle);
					bar3d(salvax1,salvay1,salvax2,salvay2,10,1);
					bar3d(salvax1,salvay1+100,salvax2,salvay2+100,10,1);
					settextstyle(2,HORIZ_DIR,8);
					outtextxy(nomex-250,nomey-180,"INSERISCI IL NOME DEL GIOCATORE:");
					outtextxy(salvascrittax,salvascrittay,"GIOCA");
					outtextxy(salvascrittax,salvascrittay+100,"ESCI");	
					delay(1);
					do{
						//SCELTA DEL NOME GIOCATORE PVE
						delay(1);
						getmouseclick(WM_LBUTTONDOWN,x,y);
						if(x<=x2lettera-550 && x>=x1lettera-550 && y>=y1lettera && y<=y2lettera){
							cout<<"Sono nel giocatore pve\n";
							lettera1++;
							if(lettera1==27){lettera1=0;}
							setcolor(stelle);
							alfabetoNome (lettera1, xlettera, ylettera, glettera, 0, nome);
						}
						if(x<=x2lettera-380 && x>=x1lettera-380 && y>=y1lettera && y<=y2lettera){
							lettera2++;
							if(lettera2==27){lettera2=0;}
							setcolor(stelle);
							alfabetoNome (lettera2, xlettera+170, ylettera, glettera, 1, nome);
						}
						if(x<=x2lettera-210 && x>=x1lettera-210 && y>=y1lettera && y<=y2lettera){
							lettera3++;
							if(lettera3==27){lettera3=0;}
							setcolor(stelle);
							alfabetoNome (lettera3, xlettera+340, ylettera, glettera, 2, nome);
						}
						if(x<=x2lettera-40 && x>=x1lettera-40 && y>=y1lettera && y<=y2lettera){
							lettera4++;
							if(lettera4==27){lettera4=0;}
							setcolor(stelle);
							alfabetoNome (lettera4, xlettera+510, ylettera, glettera, 3, nome);
						}
						if(x<=x2lettera+130 && x>=x1lettera+130 && y>=y1lettera && y<=y2lettera){
							lettera5++;
							if(lettera5==27){lettera5=0;}
							setcolor(stelle);
							alfabetoNome (lettera5, xlettera+680, ylettera, glettera, 4, nome);
						}
						if(x<=x2lettera+300 && x>=x1lettera+300 && y>=y1lettera && y<=y2lettera){
							lettera6++;
							if(lettera6==27){lettera6=0;}
							setcolor(stelle);
							alfabetoNome (lettera6, xlettera+850, ylettera, glettera, 5, nome);
						}
						if(x<=x2lettera+470 && x>=x1lettera+470 && y>=y1lettera && y<=y2lettera){
							lettera7++;
							if(lettera7==27){lettera7=0;}
							setcolor(stelle);
							alfabetoNome (lettera7, xlettera+1020, ylettera, glettera, 6, nome);
						}
						if(x<=salvax1 && x>=salvax2 && y<=salvay2 && y>=salvay1){//Se clicchi gioca dal giocatore PvE
							pronti=true;
							Beep(440,100);Beep(880,100);
							cout<<"Siamo pronti per giocare in PVE\n";
							break;//Se clicchi gioca, esci dal while
							
						}
						if(x<=salvax1 && x>=salvax2 && y<=salvay2+100 && y>=salvay1+100){//Clicchi esci dal giocatore PVE
							esci=true;
							cout<<"Si esce?";
							if(musica==0){Beep(440,100);Beep(330,100);}
						}
					
					}while(esci==false);//Se clicchi esci, vai avanti
					if(esci==true){cout<<"Dovremmo uscire\n"; closegraph();}
					if(pronti==true){cout<<"Dovrei giocare in PVE\n"; closegraph();}
				}
				//PREGIOCO PVP
				if(tipo==0 && prontiPvp==false){
					x1nome=970, y1nome=300, x2nome=1100, y2nome=420;
					delay(1);
					cout<<"Disegno il pregioco\n";
					setfillstyle(1,spazio);
					for(int i=0; i<lettere; i++){
						setcolor(COLOR(255,255,253));
						bar3d(x1nome-550,y1nome,x2nome-550,y2nome,10,1);
						x1nome+=170;
						x2nome+=170;
						cout<<"Ho disegnato un elemento del pregioco\n";
					}
					setcolor(stelle);
					bar3d(salvax1,salvay1,salvax2,salvay2,10,1);
					bar3d(salvax1,salvay1+100,salvax2,salvay2+100,10,1);
					settextstyle(2,HORIZ_DIR,8);
					outtextxy(nomex-250,nomey-180,"INSERISCI IL NOME DEL PRIMO GIOCATORE:");
					outtextxy(salvascrittax,salvascrittay,"GIOCA");
					outtextxy(salvascrittax,salvascrittay+100,"ESCI");	
					delay(1);
					do{
						//SCELTA DEL NOME GIOCATORE 1
						delay(1);
						getmouseclick(WM_LBUTTONDOWN,x,y);
						if(x<=x2lettera-550 && x>=x1lettera-550 && y>=y1lettera && y<=y2lettera){
							cout<<"Sono nel giocatore 1";
							lettera1++;
							if(lettera1==27){lettera1=0;}
							setcolor(stelle);
							alfabetoNome (lettera1, xlettera, ylettera, glettera, 0, nome);
						}
						if(x<=x2lettera-380 && x>=x1lettera-380 && y>=y1lettera && y<=y2lettera){
							lettera2++;
							if(lettera2==27){lettera2=0;}
							setcolor(stelle);
							alfabetoNome (lettera2, xlettera+170, ylettera, glettera, 1, nome);
						}
						if(x<=x2lettera-210 && x>=x1lettera-210 && y>=y1lettera && y<=y2lettera){
							lettera3++;
							if(lettera3==27){lettera3=0;}
							setcolor(stelle);
							alfabetoNome (lettera3, xlettera+340, ylettera, glettera, 2, nome);
						}
						if(x<=x2lettera-40 && x>=x1lettera-40 && y>=y1lettera && y<=y2lettera){
							lettera4++;
							if(lettera4==27){lettera4=0;}
							setcolor(stelle);
							alfabetoNome (lettera4, xlettera+510, ylettera, glettera, 3, nome);
						}
						if(x<=x2lettera+130 && x>=x1lettera+130 && y>=y1lettera && y<=y2lettera){
							lettera5++;
							if(lettera5==27){lettera5=0;}
							setcolor(stelle);
							alfabetoNome (lettera5, xlettera+680, ylettera, glettera, 4, nome);
						}
						if(x<=x2lettera+300 && x>=x1lettera+300 && y>=y1lettera && y<=y2lettera){
							lettera6++;
							if(lettera6==27){lettera6=0;}
							setcolor(stelle);
							alfabetoNome (lettera6, xlettera+850, ylettera, glettera, 5, nome);
						}
						if(x<=x2lettera+470 && x>=x1lettera+470 && y>=y1lettera && y<=y2lettera){
							lettera7++;
							if(lettera7==27){lettera7=0;}
							setcolor(stelle);
							alfabetoNome (lettera7, xlettera+1020, ylettera, glettera, 6, nome);
						}
						if(x<=salvax1 && x>=salvax2 && y<=salvay2 && y>=salvay1){prontiPvp=true; if(musica==0){Beep(440,100);Beep(880,100);} break;}//Se clicco gioca dal primo giocatore, passo al secondo
						if(x<=salvax1 && x>=salvax2 && y<=salvay2+100 && y>=salvay1+100){//Clicchi esci dal primo giocatore
							cout<<"Si esce?";
							esci=true;
							prontiPvp=false;
							if(musica==0){Beep(440,100);Beep(330,100);}
							break;
						}
					}while(esci==false || prontiPvp==false);
					cout<<"Sto per uscire dal primo giocatore\n";
					if(prontiPvp==true && esci==false){cout<<"Si passa al giocatore 2\n";
						prontiPvp=false;	
						x1nome=970, y1nome=300, x2nome=1100, y2nome=420;
						lettera1=0,lettera2=0,lettera3=0,lettera4=0,lettera5=0,lettera6=0,lettera7=0;
						closegraph();
						initwindow(1920,1080);
						cout<<"Disegno il pregioco\n";
						setfillstyle(1,spazio);
						for(int i=0; i<lettere; i++){
								setcolor(bianco);
								bar3d(x1nome-550,y1nome,x2nome-550,y2nome,10,1);
								x1nome+=170;
								x2nome+=170;
								cout<<"Ho disegnato un elemento del pregioco\n";
						}
						setcolor(bianco);
						settextstyle(2,HORIZ_DIR,8);
						bar3d(salvax1,salvay1,salvax2,salvay2,10,1);
						bar3d(salvax1,salvay1+100,salvax2,salvay2+100,10,1);
						outtextxy(nomex-350,nomey-180,"INSERISCI IL NOME DEL SECONDO GIOCATORE:");
						outtextxy(salvascrittax,salvascrittay,"GIOCA");
						outtextxy(salvascrittax,salvascrittay+100,"ESCI");	
						delay(1);
						do{
							//SCELTA DEL NOME GIOCATORE 2
							delay(1);
							getmouseclick(WM_LBUTTONDOWN,x,y);
							if(x<=x2lettera-550 && x>=x1lettera-550 && y>=y1lettera && y<=y2lettera){
								cout<<"Sto nel giocatore 2\n";
								lettera1++;
								if(lettera1==27){lettera1=0;}
								setcolor(stelle);
								alfabetoNome (lettera1, xlettera, ylettera, glettera, 0, nome2);
							}
							if(x<=x2lettera-380 && x>=x1lettera-380 && y>=y1lettera && y<=y2lettera){
								lettera2++;
								if(lettera2==27){lettera2=0;}
								setcolor(stelle);
								alfabetoNome (lettera2, xlettera+170, ylettera, glettera, 1, nome2);
							}
							if(x<=x2lettera-210 && x>=x1lettera-210 && y>=y1lettera && y<=y2lettera){
								lettera3++;
								if(lettera3==27){lettera3=0;}
								setcolor(stelle);
								alfabetoNome (lettera3, xlettera+340, ylettera, glettera, 2, nome2);
							}
							if(x<=x2lettera-40 && x>=x1lettera-40 && y>=y1lettera && y<=y2lettera){
								lettera4++;
								if(lettera4==27){lettera4=0;}
								setcolor(stelle);
								alfabetoNome (lettera4, xlettera+510, ylettera, glettera, 3, nome2);
							}
							if(x<=x2lettera+130 && x>=x1lettera+130 && y>=y1lettera && y<=y2lettera){
								lettera5++;
								if(lettera5==27){lettera5=0;}
								setcolor(stelle);
								alfabetoNome (lettera5, xlettera+680, ylettera, glettera, 4, nome2);
							}
							if(x<=x2lettera+300 && x>=x1lettera+300 && y>=y1lettera && y<=y2lettera){
								lettera6++;
								if(lettera6==27){lettera6=0;}
								setcolor(stelle);
								alfabetoNome (lettera6, xlettera+850, ylettera, glettera, 5, nome2);
							}
							if(x<=x2lettera+470 && x>=x1lettera+470 && y>=y1lettera && y<=y2lettera){
								lettera7++;
								if(lettera7==27){lettera7=0;}
								setcolor(stelle);
								alfabetoNome (lettera7, xlettera+1020, ylettera, glettera, 6, nome2);
							}
							if(x<=salvax1 && x>=salvax2 && y<=salvay2 && y>=salvay1){prontiPvp=true;  if(musica==0){Beep(440,100);Beep(880,100);} cout<<"Si gioca dal secondo player\n"; break;}//Clicchi gioca dal secondo giocatore esco dal while
							if(x<=salvax1 && x>=salvax2 && y<=salvay2+100 && y>=salvay1+100){//Clicchi esci dal secondo giocatore esco da tutto
								cout<<"Si esce?\n";
								esci=true;
								if(musica==0){Beep(440,100);Beep(330,100);}
								break;
								//bool fuorigioco=true;
						
							}
						}while(esci==false || prontiPvp==false);
					}		
					if(esci==true){cout<<"Dovremmo uscire\n"; closegraph();}
					if(prontiPvp==true){cout<<"Dovrei giocare in PVP\n"; closegraph();}//Se clico gioca dal secondo giocatore, comincio a giocare
				}	
				
				if(tipo==0&&prontiPvp==true || tipo==1&&pronti==true){sigioca=true;}
					if(sigioca==true){
						if(tipo==0){
							cout<<nome<<cout<<"\n"<<nome2<<"\n";
						}
						//GIOCO
						x1lettera+=1920;
						x2lettera+=1920;
						y1lettera+=1080;
						y2lettera+=1080;
						salvax1+=1920;
						salvax2+=1920;
						salvay1+=1080;
						salvay2+=1080;
						initwindow(1920,1080);
						if(sfondo==1){leggiBMP("Antico_Egitto.bmp");}
						if(sfondo==2){leggiBMP("Montagne_Nordiche.bmp");}
						if(sfondo==3){leggiBMP("Polo_Nord.bmp");}
						
						//RETTANGOLO TURNO
						setlinestyle(1,0,10);
						setcolor(brown_scuro);
						rounded(628,464,630,90,50);
						setfillstyle(1,spazio);
						floodfill(953,501,brown_scuro);
						setcolor(COLOR(255,255,255));
						int xTestoPrincipale=639;//Ascissa testo principale
						int yTestoPrincipale=500;//Oprdinata testo principale
						int fTestoPrincipale=3;//Font testo principale
						int gTestoPrincipale=6;//Grandezza testo principale
						setcolor(COLOR(0,0,4));
						rectangle(648,488,1282,580);
						setfillstyle(1,COLOR(0,0,5));
						floodfill(952,533,COLOR(0,0,4));
						//SUONI START
						if(musica==0){Beep (440,120); Beep (466,120); Beep (554,120); Beep (587,120); Beep (659 ,120); Beep (698 ,120); Beep (831 ,120); Beep (880 ,220);}
						//DISPOSIZIONE NOMI NEL TABELLONE
						setcolor(bianco);
						settextstyle(2,HORIZ_DIR,10);
						if(tipo==0){outtextxy(138,6,nome); outtextxy(1525,6,nome2);}
						if(tipo==1){outtextxy(138,6,nome); outtextxy(1525,6,nomeCPU);}

						int ciotole[14]={semiIniziali,semiIniziali,semiIniziali,semiIniziali,semiIniziali,semiIniziali,0,semiIniziali,semiIniziali,semiIniziali,semiIniziali,semiIniziali,semiIniziali,0};
						for(int i=0; i<14; i++){
							outNumeri(ciotole[i], i);
						}
						srand((unsigned)time(NULL));
						int giocatore = 1;
						int granaio = 6;
						int granaioAvversario = 13;
						int mossa=0;//cella da dove tutto parte
						int c;
						bool mossaSelezionata=false;//Booleano per capire se clicco la ciotola
						bool ToccaAlloStessoGiocatore=false;
						bool Vittoria = false;
						bool fineStampa=false;
						bool VittoriaGiocatore1;
						bool VittoriaGiocatore2;
						int x1ciotole=345, x2ciotole=465, y1ciotole=650, y2ciotole=787;
						int turno;
						turno=rand() % 2 + 1;
						settextstyle(2,HORIZ_DIR,10);
						setcolor(stelle);
						settextstyle(fTestoPrincipale,HORIZ_DIR,gTestoPrincipale);
						if(tipo==0){outtextxy(xTestoPrincipale+120,yTestoPrincipale,"B E N V E N U T I"); delay(2000);}
						if(tipo==1){outtextxy(xTestoPrincipale+120,yTestoPrincipale,"B E N V E N U T O"); delay(2000);}						
						do {
							mossaSelezionata=false;
							bool furto=false;
							cout << turno << "\n";
							if (turno % 2 == 0) { giocatore = 1; granaio = 6; granaioAvversario = 13; }
							if(turno%2!=0 && ToccaAlloStessoGiocatore==false) { giocatore = 2; swap(granaio, granaioAvversario); }
							if(tipo==1 && giocatore==2 && ToccaAlloStessoGiocatore==true){delay(1000);}
							//RETTANGOLO PER OSCURARE IL TESTO PRECEDENTE NEL RETTANGOLO CENTRALE
							setcolor(COLOR(0,0,4));
							rectangle(648,488,1282,580);
							setfillstyle(1,COLOR(0,0,5));
							floodfill(952,533,COLOR(0,0,4));
							//TESTO PER IL RETTANGOLO CENTRALE
							delay(1);
							setcolor(COLOR(255,255,255));
							outtextxy (xTestoPrincipale+100,yTestoPrincipale,"Tocca a" );
							if(giocatore==1){delay(1); outtextxy(xTestoPrincipale+320,yTestoPrincipale,nome);}
							if(giocatore==2){if(tipo==1){delay(1); outtextxy(xTestoPrincipale+320,yTestoPrincipale,nomeCPU);} else{	delay(1); outtextxy(xTestoPrincipale+320,yTestoPrincipale,nome2);}}
							ToccaAlloStessoGiocatore = false;
							cout << "Giocatore " << giocatore << " da dove vuoi partire?\n";
							cout << "Il granaio \x8a "<<granaio << "\n";
							if(giocatore==1){
								cout<<"Il giocatore 1 seleziona la mossa\n";
								do{
									delay(1);
									getmouseclick(WM_LBUTTONDOWN,x,y);
									if(x<=x2ciotole && x>=x1ciotole && y<=y2ciotole && y>=y1ciotole /*&& ciotole[0]!=0*/){ mossa=0;mossaSelezionata=true;}
									if(x<=x2ciotole+220 && x>=x1ciotole+220 && y<=y2ciotole && y>=y1ciotole && ciotole[1]!=0){ mossa=1; cout<<"Hai cliccato la mossa "<<mossa<<"\n"; mossaSelezionata=true;}
									if(x<=x2ciotole+440 && x>=x1ciotole+440 && y<=y2ciotole && y>=y1ciotole&& ciotole[2]!=0){ mossa=2; cout<<"Hai cliccato la mossa "<<mossa<<"\n"; mossaSelezionata=true;}
									if(x<=x2ciotole+660 && x>=x1ciotole+660 && y<=y2ciotole && y>=y1ciotole&& ciotole[3]!=0){ mossa=3; cout<<"Hai cliccato la mossa "<<mossa<<"\n"; mossaSelezionata=true;}
									if(x<=x2ciotole+880 && x>=x1ciotole+880 && y<=y2ciotole && y>=y1ciotole&& ciotole[4]!=0){ mossa=4; cout<<"Hai cliccato la mossa "<<mossa<<"\n"; mossaSelezionata=true;}
									if(x<=x2ciotole+1100 && x>=x1ciotole+1100 && y<=y2ciotole && y>=y1ciotole&& ciotole[5]!=0){ mossa=5; cout<<"Hai cliccato la mossa "<<mossa<<"\n"; mossaSelezionata=true;}
								}while(mossaSelezionata==false);
								
							}
							if(giocatore==2 && tipo==0){
								cout<<"Il giocatore 2 seleziona la mossa\n";
								do{
									delay(1);
								getmouseclick(WM_LBUTTONDOWN,x,y);
								if(x<=x2ciotole && x>=x1ciotole && y<=y2ciotole-390 && y>=y1ciotole-390 && ciotole[12]!=0){ mossa=12;mossaSelezionata=true;}
								if(x<=x2ciotole+220 && x>=x1ciotole+220 && y<=y2ciotole-390 && y>=y1ciotole-390  && ciotole[11]!=0){ mossa=11; cout<<"Hai cliccato la mossa "<<mossa<<"\n"; mossaSelezionata=true;}
								if(x<=x2ciotole+440 && x>=x1ciotole+440 && y<=y2ciotole-390 && y>=y1ciotole-390  && ciotole[10]!=0){ mossa=10; cout<<"Hai cliccato la mossa "<<mossa<<"\n"; mossaSelezionata=true;}
								if(x<=x2ciotole+660 && x>=x1ciotole+660 && y<=y2ciotole-390 && y>=y1ciotole-390  && ciotole[9]!=0){ mossa=9; cout<<"Hai cliccato la mossa "<<mossa<<"\n"; mossaSelezionata=true;}
								if(x<=x2ciotole+880 && x>=x1ciotole+880 && y<=y2ciotole-390 && y>=y1ciotole-390  && ciotole[8]!=0){ mossa=8; cout<<"Hai cliccato la mossa "<<mossa<<"\n"; mossaSelezionata=true;}
								if(x<=x2ciotole+1100 && x>=x1ciotole+1100 && y<=y2ciotole-390 && y>=y1ciotole-390 && ciotole[7]!=0){ mossa=7; cout<<"Hai cliccato la mossa "<<mossa<<"\n"; mossaSelezionata=true;}
								}while(mossaSelezionata==false);
							}
							//GIOCATORE 2 PVE
							if(giocatore==2 && tipo==1){
								int semiPvp;
								bool ladrata=false;
								bool corriCasa=false;
								bool daiNoia=false;
								for(int k=7; k<13 || k<13 && ladrata==false || k<13 && corriCasa==false; k++){
									semiPvp=ciotole[k];
									cout<<k<<"\n";
									if(ciotole[k+semiPvp]==0 && semiPvp+k < 13 && ciotole[k]!=0){mossa=k; cout<<"La CPU te frega i fagioli\n"; ladrata=true; break;}
									if(k+semiPvp==granaio && ciotole[k]!=0){mossa=k; cout<<"La CPU va nel granaio easy easy\n"; corriCasa=true; break;}
								}
								/*for(int j=7; j<12 && ladrata==false && corriCasa==false; j++){
									int max=ciotole[13];
									cout<<"La CPU tenta di dare noia\n";
									if(ciotole[j+semiPvp]>granaio && ciotole[j]>0){mossa=j; daiNoia=true; break; }
								}*/
								
								if(ladrata==false && corriCasa==false && daiNoia==false){
									cout<<"La CPU tenta di dare noia\n";
									if(ciotole[12]!=0){mossa=12;}
									else{for(int h=7; h<13; h++){if(ciotole[h]>0){mossa=h; break;}}}
								}	
							}
							cout<<"La mossa \x8a "<<mossa<<"\n";
							c=mossa;//Contatore per la stampa dei numeri
							int semi = ciotole[mossa];
							ciotole[mossa] = 0;
							for (int i = 1; i <= semi; i++) {
								if (mossa + i != granaioAvversario) {
									cout << "Aggiungo di 1 ai semi della " << i << " casella successiva\n";
									ciotole[mossa + i]++;
								}
								else { semi++; cout << "Aggiungo un seme\n"; }
								if (mossa + i >= 14) { mossa = -i - 1;  semi++;}
							}
							if(giocatore==2 && mossa+semi>6 || giocatore==1){
								if (ciotole[mossa + semi] == 1 && mossa + semi < granaio && ciotole[13-(mossa+semi)-1]!=0) { furto=true; cout << "Furto\n"; ciotole[granaio] += 1 + ciotole[13-(mossa+semi)-1]; ciotole[mossa+semi]=0; ciotole[13-(mossa+semi)-1]=0; cout<<"La ciotola rubata vale "<<ciotole[13-(mossa+semi)-1]<<"\n La ciotola che ha rubato vale "<<ciotole[mossa+semi]<<"\n";
									//RETTANGOLO PER OSCURARE IL TESTO PRECEDENTE NEL RETTANGOLO CENTRALE
									setcolor(COLOR(0,0,4));
									rectangle(648,488,1282,580);
									setfillstyle(1,COLOR(0,0,5));
									floodfill(952,533,COLOR(0,0,4));
									//TESTO PER IL RETTANGOLO CENTRALE
									delay(1);
									setcolor(COLOR(255,0,0));
									outtextxy (xTestoPrincipale+100,yTestoPrincipale,"Attenzione FURTO");
									delay(100);
								}
							}
							
							for (int i = 0; i < 14; i++) {
								cout << ciotole[i] << " - ";
							}
							//cout<<c<<"\n\n";
							int k=0;//Altro contatore per la stampa dei numeri
							while(k<=13){
								if(k<=semi){
									if(furto==true){
										if(k==semi){
											delay(600);
											outNumeri(1,c);
											if(musica==0){if(giocatore==2 && k<13){Beep(415,50);} if(giocatore==1){Beep(554,50);}}
										}
									}
									delay(600);
									if(c==14){c=0;}
									outNumeri(ciotole[c],c);
									if(musica==0&&k>0 ){if(giocatore==2){Beep(440,50);} if(giocatore==1){Beep(587,50);}}
								}
								else{delay(1); if(c==14){c=0;} outNumeri(ciotole[c],c);}
								c++;
								k++;
								cout<<c;
							}
							cout << "Ho stampato l'array\n";
							if (mossa + semi == granaio) { cout << "Tocca ancora a me\n"; ToccaAlloStessoGiocatore = true; }
							for (int i = 0; i < 6; i++) {
								if (ciotole[i] != 0) {
									VittoriaGiocatore1 = false;
									break;
								}
								else { VittoriaGiocatore1 = true; }
							}
							for (int i = 7; i < 13; i++) {
								if (ciotole[i] != 0) {
									VittoriaGiocatore2 = false;
									break;
								}
								else{ VittoriaGiocatore2 = true; }
							}
							if (VittoriaGiocatore1 == true) { break; }
							if (VittoriaGiocatore2 == true) { break; }
							if (ToccaAlloStessoGiocatore == false) { turno++; }
						} while (VittoriaGiocatore1 == false || VittoriaGiocatore2==false);
						if (VittoriaGiocatore1 == true || VittoriaGiocatore2 == true) {
							if(tipo==0){
								if(ciotole[6]>ciotole[13]){cout << "Ha vinto il giocatore 1\n";	
									//OUTPUT VINTO
									closegraph();
									initwindow(1920,1080);
									setcolor(verde);
									setlinestyle(0,0,2);
									 GeneraStelle(verde, temporaneo);
									setcolor(verde);
									settextstyle(DEFAULT_FONT,HORIZ_DIR,10);
									outtextxy(getmaxx()/2-300,getmaxy()/3, "HAI VINTO");
									settextstyle(DEFAULT_FONT,HORIZ_DIR,4);
									outtextxy(getmaxx()/2-70,getmaxy()/2,nome);
									//SUONI VITTORIA
									if(musica==0){Beep (440,100); Beep (554,100); Beep (659,100); Beep (880,200);}
									delay(5000);
								}
								else if(ciotole[13]>ciotole[6]){cout << "Ha vinto il giocatore 2\n";
									//OUTPUT VINTO
									closegraph();
									initwindow(1920,1080);
									setcolor(arancio);
									GeneraStelle(arancio, temporaneo);
									setcolor(arancio);
									settextstyle(DEFAULT_FONT,HORIZ_DIR,10);
									outtextxy(getmaxx()/2-300,getmaxy()/3, "HAI VINTO");
									settextstyle(DEFAULT_FONT,HORIZ_DIR,4);
									outtextxy(getmaxx()/2-70,getmaxy()/2,nome2);
									//SUONI VITTORIA
									if(musica==0){Beep (440,100); Beep (554,100); Beep (659,100); Beep (880,200);}
									delay(5000);
								}
							}
							else{
								if(ciotole[6]>ciotole[13]){cout << "Ha vinto il giocatore\n";	
									//OUTPUT VINTO
									closegraph();
									initwindow(1920,1080);
									setcolor(verde);
									GeneraStelle(verde, temporaneo);
									setcolor(verde);
									settextstyle(DEFAULT_FONT,HORIZ_DIR,10);
									outtextxy(getmaxx()/2-300,getmaxy()/3, "HAI VINTO");
									settextstyle(DEFAULT_FONT,HORIZ_DIR,4);
									outtextxy(getmaxx()/2-70,getmaxy()/2,nome);
									//SUONI VITTORIA
									if(musica==0){Beep (440,100); Beep (554,100); Beep (659,100); Beep (880,200);} 
									delay(5000);
								}
								else if(ciotole[13]>ciotole[6]){cout << "Ha vinto il computer\n";
									closegraph();
									initwindow(1920,1080);
								    GeneraStelle(rosso, temporaneo);
									setcolor(rosso);
									settextstyle(DEFAULT_FONT,HORIZ_DIR,10);
									outtextxy(getmaxx()/2-350,getmaxy()/3, "HAI PERSO");
									settextstyle(DEFAULT_FONT,HORIZ_DIR,4);
									outtextxy(getmaxx()/2-430,getmaxy()/2,"la macchina ha battuto ");
									outtextxy(getmaxx()/2+300,getmaxy()/2,nome);
									if(musica==0){Beep (440,100); Beep (330,100); Beep (262,100); Beep (220,200);}
									delay(5000);
								
								}
									
							}
						}
					}
			}
		//SE CLICCHI OPZIONI
		if(GetAsyncKeyState(VK_LBUTTON) && x>800 && x<1301 && y>500 && y<620 && menu==true){
			esci=false;
			closegraph();
			menu=false;
			cout<<"Sono nelle opzioni\n";
			initwindow(1920,1080);
			delay(1);
			int x1ret=970, y1ret=300, x2ret=1100, y2ret=420;
			settextstyle(GOTHIC_FONT,HORIZ_DIR,20);
			outtextxy(560,90,"OPZIONI");
			settextstyle(GOTHIC_FONT,HORIZ_DIR,8);
			setcolor(giallo);
			outtextxy(200,320,"Semi iniziali: ");
			setfillstyle(1,spazio);
			bar3d(x1ret, y1ret, x2ret, y2ret,10,1);
			setcolor(arancio);
			outtextxy(200,480,"Modalit�: ");
			bar3d(x1ret, y1ret+150, x2ret+150, y2ret+150,10,1);
			setcolor(rosso);
			outtextxy(200,640,"Sfondo: ");
			bar3d(x1ret, y1ret+300, x2ret+620, y2ret+300,10,1);
			setcolor(viola);
			outtextxy(200,820,"Suoni: ");
			bar3d(x1ret, y1ret+450, x2ret+90, y2ret+450,10,1);
			setcolor(stelle);
			bar3d(1370,y1ret-20,x2ret+620,y2ret,10,1);
			outtextxy(1400,y1ret,"salva");
			/*int semiIniziali=3;
			int tipo=0;
			int sfondo=1;
			int musica=0;*/
			int xOpz=1000;
			int yOpz=320;
			do{
				delay(1);
				do{
					delay(1);
					//INGRANDIMENTO USCITA	
				}while(!ismouseclick(WM_LBUTTONDOWN));
				getmouseclick(WM_LBUTTONDOWN,x,y);
			
				//SEMI INIZIALI
				if(x<=x2ret && x>=x1ret && y<=y2ret && y>=y1ret){
					setcolor(giallo);
					semiIniziali++;
					if(semiIniziali==7){semiIniziali=3;}
					switch (semiIniziali){
						settextstyle(10,5,9);
						case 3:{
							delay(0);
							outtextxy(xOpz,yOpz,"3");
							cout<<semiIniziali;
							break;
						}
						case 4:{
							delay(0);
							outtextxy(xOpz,yOpz,"4");
							cout<<semiIniziali;
							break;
						}
						case 5:{
							delay(0);
							outtextxy(xOpz,yOpz,"5");
							cout<<semiIniziali;
							break;
						}
						case 6:{
							delay(0);
							outtextxy(xOpz,yOpz,"6");
							cout<<semiIniziali;
							break;
						}
					}
				}
				//MODALITA'
				if(x<=x2ret+150 && x>=x1ret && y<=y2ret+150 && y>=y1ret+150){
					setcolor(arancio);
					tipo++;
					if(tipo==2){tipo=0;}
					switch (tipo){
						case 0:{
							outtextxy(xOpz,yOpz+150,"PvP");
							cout<<tipo;
							break;
						}
						case 1:{
							outtextxy(xOpz,yOpz+150,"PvE");
							cout<<tipo;
							break;
						}
					}
				}
				
				//SFONDO
				if(x<=x2ret+620 && x>=x1ret && y<=y2ret+300 && y>=y1ret+300){
					sfondo++;
					if(sfondo==4){sfondo=1;}
					switch (sfondo){
						case 1:{
							setcolor(nero);
							rectangle(x1ret+10,y1ret+310,x2ret+600,y2ret+290);
							setfillstyle(1,spazio);
							floodfill(x1ret+100,y1ret+350,nero);
							setcolor(rosso);
							outtextxy(xOpz,yOpz+300,"Antico Egitto");
							cout<<sfondo;
							break;
						}
						case 2:{
							setcolor(nero);
							rectangle(x1ret+10,y1ret+310,x2ret+600,y2ret+290);
							setfillstyle(1,spazio);
							floodfill(x1ret+100,y1ret+350,nero);
							setcolor(rosso);
							outtextxy(xOpz, yOpz+300,"Montagne");
							cout<<sfondo;
							break;
						}
						case 3:{
							setcolor(nero);
							rectangle(x1ret+10,y1ret+310,x2ret+600,y2ret+290);
							setfillstyle(1,spazio);
							floodfill(x1ret+100,y1ret+350,nero);
							setcolor(rosso);
							outtextxy(xOpz,yOpz+300,"Polo Nord");
							cout<<sfondo;
							break;
						}
					}
				}
				
				//SUONI
				if(x<=x2ret+90 && x>=x1ret && y<=y2ret+450 && y>=y1ret+450){
					setcolor(viola);
					musica++;
					if(musica==2){musica=0;}
					switch (musica){
						case 0:{
							setcolor(nero);
							rectangle(x1ret+10,y1ret+460,x2ret+80,y2ret+440);
							setfillstyle(1,spazio);
							floodfill(x1ret+100,y1ret+480,nero);
							setcolor(viola);
							outtextxy(xOpz,yOpz+450,"Si");
							cout<<1;
							if(musica==0){Beep (440,50); Beep (880,100); }
							break;
						}
						case 1:{
							outtextxy(xOpz,yOpz+450,"No");
							cout<<0;
							break;
						}
					}
				}
				//PULSANTE USCITA
				if(x>=1370 && x<=x2ret+620 && y>= y1ret-20 && y<=y2ret){ if(musica==0){Beep (440,50); Beep (880,100);} esci=true; cout<<"esci";}
				
			}while(esci==false);
			if (esci==true){closegraph();}
					
		}

	  	}
   	
	  }while(esci==true);
		

}
/*CHECK LIST
*/
